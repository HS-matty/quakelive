<?php
error_reporting(E_ALL);

require_once('vendor/autoload.php');
use Radmaster\Toolkit\Std;

$std_class = new Std();
//$std_class->_version = '[Radmaster Toolkit /  version 0.9]';

?>

<html>
<body>
<center>

<h1>ql.ebase.in </h1>
<h3>Quakelive Servers Network</h3>
<h4>Using <?php echo Std::getVersion(); ?></h4>
<h4>Powered by [The-Great-Imperror-of-the-Univerce]   </h4>
<h5>Inspired by  | Dolores O`Riordan Radzivilus |</h5>
<h5> Call to: <a href="callto://+375259520051">+375259520051</a>
<br> Timestamp: <?php echo time(); ?> 
<br><br><br>
<a href="https://companies.dev.by/hytex-development-studio"><img src="https://companies.dev.by/system/companies/logos/75678/pre_medium_white/5bb0d085b7f16f511936a77ae8155538.png"></a>
</center>
</body>
</html>